package me.deqes.event;

import lombok.AllArgsConstructor;
import lombok.Getter;
import net.minecraft.class_332;
@AllArgsConstructor @Getter
public class EventRender
{
    class_332 context;

}

package me.deqes;
import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import lombok.Getter;
import lombok.Synchronized;
import me.deqes.event.EventTick;
import me.deqes.module.ModuleManager;
import net.fabricmc.api.ModInitializer;

public class Laguna implements ModInitializer {

    @Getter
    private static Laguna instance;
    @Getter
    private  static EventBus eventBus;
    @Getter
    private static ModuleManager moduleManager;

    @Override
    public void onInitialize() {
        instance = this;
        eventBus = new EventBus();
        eventBus.register(this);
        moduleManager = new ModuleManager();
    }


}

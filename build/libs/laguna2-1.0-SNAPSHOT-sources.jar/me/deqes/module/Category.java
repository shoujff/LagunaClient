package me.deqes.module;

public enum Category
{
    RENDER,
    COMBAT

}

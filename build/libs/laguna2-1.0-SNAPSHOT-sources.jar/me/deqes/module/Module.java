package me.deqes.module;

import lombok.Getter;
import lombok.Setter;
import me.deqes.Laguna;

public class Module {
    @Getter
    String name;
    @Getter
    Category category;
    @Getter @Setter
    int bind;

    boolean toggled;


    public Module(String name, Category category, int bind)
    {
        this.name = name;
        this.category = category;
        this.bind = bind;
    }

    public void onEnable(){
        Laguna.getInstance().getEventBus().register(this);
    }
    public void onDisable(){
        Laguna.getInstance().getEventBus().register(this);

    }
    public void Toggle(){
        if(toggled){
            toggled = false;
            onDisable();
        } else{
            toggled = true;
            onEnable();
        }
    }
}

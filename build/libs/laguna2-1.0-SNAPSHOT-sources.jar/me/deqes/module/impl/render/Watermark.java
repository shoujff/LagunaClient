package me.deqes.module.impl.render;

import com.google.common.eventbus.Subscribe;
import jdk.jfr.Event;
import me.deqes.event.EventRender;
import me.deqes.module.Category;
import me.deqes.module.Module;

public class Watermark  extends Module {
    public Watermark() {
        super("Watermark", Category.RENDER, 80);

    }

    @Subscribe
    public void onRender(EventRender e)
    {
        e.getContext().fill(10,10,100,100,0xFFFFFFFF);
    }
}

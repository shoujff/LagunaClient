package me.deqes.mixin;

import me.deqes.Laguna;
import me.deqes.event.EventKey;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    public void onKey(long window, int action, class_11908 input, CallbackInfo ci)
    {
        EventKey eventKey = new EventKey(input.comp_4795(), action);
        Laguna.getInstance().getEventBus().post(eventKey);
    }

}

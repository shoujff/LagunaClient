package me.deqes.mixin;

import lombok.AllArgsConstructor;
import me.deqes.Laguna;
import me.deqes.event.EventRender;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("HEAD") )
    public void onRender(class_332 context, class_9779 tickCounter, CallbackInfo ci){
        EventRender eventRender = new EventRender(context);
        Laguna.getInstance().getEventBus().post(eventRender);
    }

}
